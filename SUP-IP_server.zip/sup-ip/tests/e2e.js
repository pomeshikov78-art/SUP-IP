const puppeteer = require('puppeteer');
const BASE = 'http://127.0.0.1:8000';
let PASS=0, FAIL=0;
const ok=(name,cond,extra='')=>{ if(cond){PASS++;console.log('  ok  '+name);} else {FAIL++;console.log('FAIL  '+name+'  '+extra);} };
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

(async()=>{
 const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage']});
 const page = await browser.newPage();
 await page.setViewport({width:1440,height:900});
 const errors=[];
 page.on('pageerror',e=>errors.push('pageerror: '+e.message));
 page.on('console',m=>{ if(m.type()==='error' && !/401|403|400|429|Failed to load resource/.test(m.text())) errors.push('console: '+m.text()); });

 // эталонный набор до и после испытаний: UI-тесты не зависят от прежнего состояния БД
 const rpcAs = async (cookie,action,payload)=>{
  const r = await fetch(BASE+'/api/rpc',{method:'POST',headers:{'Content-Type':'application/json',cookie},
   body:JSON.stringify({action,payload:payload||{}})});
  return r.json();
 };
 const admSess = await fetch(BASE+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({login:'admin',password:'demo'})});
 const admCookie = (admSess.headers.get('set-cookie')||'').split(';')[0];
 await rpcAs(admCookie,'admin.reset');

 console.log('== Загрузка и вход ==');
 await page.goto(BASE,{waitUntil:'networkidle0'});
 ok('экран входа', await page.$('.login-box')!==null);
 ok('8 демо-карточек', (await page.$$('.user-pick')).length===8);
 await page.evaluate(()=>{ App.pickUser('volkova'); });
 await page.click('.login-row .btn.pri');
 await page.waitForSelector('.shell',{timeout:10000});
 ok('оболочка после входа', await page.$('.sidebar')!==null);
 await sleep(400);
 ok('дашборд: KPI виджеты', (await page.$$('.kpi')).length>=4);
 ok('роль РП видна', (await page.evaluate(()=>App.user.role))==='pm');
 await page.screenshot({path:'/tmp/e2e/shot_dash.png'});

 console.log('== Модули: рендер ==');
 for(const [key,sel] of [['portfolio','.tbl'],['tasks','.tbl'],['kanban','.kb-col'],['gantt','svg'],['resources','.card'],['time','.tbl'],['control','.card'],['risks','.tbl'],['docs','.tbl'],['calcs','.tbl'],['analytics','svg'],['calendar','.cal-cell'],['reports','.card'],['meetings','.tbl'],['journal','.tbl'],['builder','.scenario']]){
  await page.evaluate(k=>nav(k),key);
  await sleep(250);
  const has = await page.$(sel)!==null;
  ok('рендер '+key, has);
 }

 console.log('== Создание проекта через форму ==');
 await page.evaluate(()=>nav('portfolio'));
 await sleep(250);
 await page.evaluate(()=>App.projModal(null));
 await sleep(150);
 await page.evaluate(()=>{
  document.getElementById('pm-name').value='E2E проект браузера';
  document.getElementById('pm-start').value='2026-12-01';
  document.getElementById('pm-end').value='2027-03-01';
  document.getElementById('pm-budget').value='500';
 });
 await page.evaluate(()=>App.projSave(null));
 await sleep(700);
 const pcode = await page.evaluate(()=>{const p=DB.projects.find(x=>x.name==='E2E проект браузера');return p?p.code:null;});
 ok('проект создан на сервере', !!pcode, pcode);
 ok('drawer открыт с кодом', (await page.evaluate(()=>document.getElementById('drawer-root').textContent)).includes(pcode||'@@'));

 console.log('== Задача + канбан + гант ==');
 const tid = await page.evaluate(async()=>{
  const p=DB.projects.find(x=>x.name==='E2E проект браузера');
  const r=await rpc('task.create',{projectId:p.id,title:'E2E задача',assignee:'u5',start:'2026-12-01',end:'2026-12-10',planHours:24,priority:'Высокий',initialStatus:'Готова к выполнению'});
  return r?r.id:null;
 });
 ok('задача создана', !!tid);
 await page.evaluate(()=>nav('kanban'));
 await sleep(300);
 await page.evaluate(t=>App.kbApply(t,KB_COLS.find(c=>c.key==='work'),['В работе']),tid);
 await sleep(600);
 ok('канбан: карточка В работе', (await page.evaluate(t=>T_(t).status,tid))==='В работе');
 await page.screenshot({path:'/tmp/e2e/shot_kanban.png'});
 await page.evaluate(()=>nav('gantt'));
 await sleep(300);
 ok('гант отрисован', await page.$('svg')!==null);

 console.log('== Трудозатраты через форму ==');
 await page.evaluate(()=>nav('time'));
 await sleep(250);
 await page.evaluate(()=>App.timeModal(null));
 await sleep(150);
 await page.evaluate(t=>{
  document.getElementById('te-date').value='2026-11-24';
  document.getElementById('te-hours').value='4';
  const sel=document.getElementById('te-task');
  sel.innerHTML='<option value="'+t+'">E2E</option>'; sel.value=t;
 },tid);
 await page.evaluate(()=>App.timeSave(null));
 await sleep(600);
 ok('часы записаны (сервер)', await page.evaluate(()=>DB.time.some(e=>e.comment!==undefined&&e.hours===4&&e.date==='2026-11-24')));

 console.log('== Расчёт через мастер ==');
 const calcOk = await page.evaluate(async()=>{
  const p=DB.projects.find(x=>x.name==='E2E проект браузера');
  const r=await rpc('calc.run',{model:'link',title:'E2E бюджет',projectId:p.id,inputs:{f:5000,d:10,ptx:20,gtx:20,grx:20,lmisc:5,sens:-90}});
  return r && r.outputs && r.outputs.ok===true;
 });
 ok('расчёт выполнен сервером', calcOk===true);

 console.log('== Документ: реальная загрузка файла ==');
 const fs=require('fs');
 fs.writeFileSync('/tmp/e2e/test_doc.txt','E2E file content — проверка хранилища M09');
 await page.evaluate(()=>nav('docs'));
 await sleep(250);
 await page.evaluate(()=>App.docModal(null,false));
 await sleep(150);
 await page.evaluate(()=>{
  document.getElementById('dm-title').value='E2E документ';
  const p=DB.projects.find(x=>x.name==='E2E проект браузера');
  document.getElementById('dm-proj').value=p.id;
 });
 const fi = await page.$('#dm-file');
 await fi.uploadFile('/tmp/e2e/test_doc.txt');
 await page.evaluate(()=>App.docSave(null,false));
 await sleep(900);
 const docId = await page.evaluate(()=>{const d=DB.docs.find(x=>x.title==='E2E документ');return d?d.id:null;});
 ok('документ создан', !!docId);
 const fileCheck = await page.evaluate(async id=>{
  const d=DB.docs.find(x=>x.id===id);
  const r=await fetch('/api/files/'+id+'/1'); const txt=await r.text();
  return {stored:d.versions[0].stored, match:txt.includes('E2E file content')};
 },docId);
 ok('файл сохранён на сервере (stored)', fileCheck.stored===true);
 ok('скачивание = загруженному', fileCheck.match===true);

 console.log('== Отчёт и журнал ==');
 await page.evaluate(()=>nav('reports'));
 await sleep(250);
 await page.evaluate(()=>App.reportGen());
 await sleep(700);
 ok('отчёт открыт в модале', (await page.evaluate(()=>document.getElementById('modal-root').textContent)).includes('ОТ-'));
 await page.evaluate(()=>App.closeModal(true));
 await page.evaluate(()=>nav('journal'));
 await sleep(300);
 ok('журнал содержит BUSINESS', (await page.evaluate(()=>document.getElementById('view').textContent)).includes('BUSINESS'));

 console.log('== Центр уведомлений и напоминаний (M12 §8) ==');
 // совещание создаёт другой пользователь (администратор) — приглашение должно прийти в браузер РП
 const mtRes = await rpcAs(admCookie,'meeting.create',{title:'E2E совещание уведомлений',type:'Оперативное',
  date:new Date(Date.now()+864e5).toISOString().slice(0,10),time:'11:00',chair:'u2',secretary:'u4',attendees:['u3','u5']});
 const mid = (mtRes.result||{}).id;
 ok('совещание создано вторым пользователем', !!mid);
 await page.evaluate(()=>pollState());
 await sleep(400);
 ok('счётчик непрочитанных обновлён', (await page.evaluate(()=>DB.notifUnread))>=1);
 ok('бейдж уведомлений видим', await page.evaluate(()=>{const b=document.getElementById('notif-bdg');return b&&b.style.display!=='none';}));
 await page.evaluate(()=>App.notifs());
 await sleep(200);
 ok('попап центра уведомлений открыт', await page.$('.notif-pop')!==null);
 ok('приглашение доставлено сервером', (await page.evaluate(()=>document.getElementById('notif-pop').textContent)).includes('Приглашение: E2E совещание уведомлений'));
 ok('есть раздел подсказок из состояния', (await page.evaluate(()=>document.getElementById('notif-pop').textContent)).includes('Требует внимания'));
 await page.screenshot({path:'/tmp/e2e/shot_notifs.png'});
 const unreadBefore = await page.evaluate(()=>DB.notifUnread);
 await page.evaluate(()=>{ const i=App._notifs.findIndex(n=>n.title.includes('Приглашение')); App.notifGo(i,'srv'); });
 await sleep(600);
 ok('переход к совещанию из уведомления', (await page.evaluate(()=>document.getElementById('drawer-root').textContent)).includes('E2E совещание уведомлений'));
 ok('уведомление отмечено прочитанным', (await page.evaluate(()=>DB.notifUnread))<unreadBefore);
 await page.evaluate(()=>{App.closeDrawer&&App.closeDrawer(true);App.notifs();});
 await sleep(200);
 await page.evaluate(()=>App.notifReadAll());
 await sleep(600);
 ok('«Прочитать все» обнулило счётчик', (await page.evaluate(()=>DB.notifUnread))===0);
 ok('бейдж скрыт после прочтения', await page.evaluate(()=>{const b=document.getElementById('notif-bdg');return b&&b.style.display==='none';}));

 await page.evaluate(()=>App.notifPrefs());
 await sleep(400);
 ok('модалка настроек уведомлений', (await page.evaluate(()=>document.getElementById('modal-root').textContent)).includes('Настройка уведомлений'));
 ok('чекбоксы типов отрисованы', await page.$('#np-task\\.overdue')!==null);
 await page.evaluate(()=>{document.getElementById('np-task.overdue').checked=false;});
 await page.evaluate(()=>App.notifPrefsSave());
 await sleep(600);
 const prefsOff = await page.evaluate(async()=>{const r=await rpc('notif.list',{limit:1});return r&&r.prefs['task.overdue']===false;});
 ok('отключённый тип сохранён на сервере', prefsOff===true);
 await page.evaluate(()=>rpc('notif.prefs',{prefs:{'task.overdue':true}}));
 await sleep(300);

 console.log('== Напоминания совещания и события ==');
 await page.evaluate(m=>{App.f.meetTab='info';openMeeting(m);},mid);
 await sleep(400);
 ok('блок напоминаний в карточке совещания', (await page.evaluate(()=>document.getElementById('drawer-root').textContent)).includes('Напоминания'));
 ok('типовые интервалы отмечены', await page.evaluate(()=>{const a=document.getElementById('rem-meeting-1440'),b=document.getElementById('rem-meeting-60');return a&&a.checked&&b&&b.checked;}));
 await page.evaluate(()=>{document.getElementById('rem-meeting-10080').checked=true;});
 await page.evaluate(m=>App.reminderSave('meeting',m),mid);
 await sleep(700);
 const remM = await page.evaluate(m=>DB.reminders.filter(r=>r.owner_id===m).map(r=>r.offset_min),mid);
 ok('напоминания пересчитаны сервером (3 интервала × 4 участника)', remM.length===12, remM.length);
 ok('новый интервал сохранён', [...new Set(remM)].sort((a,b)=>a-b).join(',')==='60,1440,10080');
 // перенос совещания другим пользователем: оповещение участников и пересчёт напоминаний
 const fireBefore = await page.evaluate(m=>DB.reminders.filter(r=>r.owner_id===m).map(r=>r.fire_at).sort().join(','),mid);
 await rpcAs(admCookie,'meeting.update',{id:mid,date:new Date(Date.now()+3*864e5).toISOString().slice(0,10),time:'12:30'});
 await page.evaluate(()=>pollState());
 await sleep(400);
 ok('участник оповещён о переносе', await page.evaluate(()=>DB.notifications.some(n=>n.title.includes('Совещание перенесено'))));
 const fireAfter = await page.evaluate(m=>DB.reminders.filter(r=>r.owner_id===m).map(r=>r.fire_at).sort().join(','),mid);
 ok('напоминания пересчитаны от новой даты', fireBefore!==fireAfter && fireAfter.split(',').length===12);

 await page.evaluate(()=>{App.closeDrawer&&App.closeDrawer(true);App.calEventModal(D(2));});
 await sleep(300);
 ok('чекбоксы напоминаний в форме события', await page.evaluate(()=>{const a=document.getElementById('cev-rem-1440'),b=document.getElementById('cev-rem-60');return a&&a.checked&&b&&b.checked;}));
 await page.evaluate(()=>{
  document.getElementById('cev-title').value='E2E событие с напоминаниями';
  document.getElementById('cev-rem-60').checked=false;
  document.getElementById('cev-rem-10080').checked=true;
 });
 await page.evaluate(()=>App.calEventSave());
 await sleep(900);
 const evInfo = await page.evaluate(()=>{
  const e=DB.calEvents.find(x=>x.title==='E2E событие с напоминаниями');
  return e?{id:e.id,offs:[...new Set(DB.reminders.filter(r=>r.owner_id===e.id).map(r=>r.offset_min))].sort((a,b)=>a-b)}:null;
 });
 ok('событие календаря создано', !!(evInfo&&evInfo.id));
 ok('выбранные интервалы напоминаний применены', evInfo&&evInfo.offs.join(',')==='1440,10080', evInfo&&evInfo.offs.join(','));
 await page.evaluate(()=>nav('meetings'));
 await sleep(250);

 console.log('== M16 §2.9: маршрут согласования и версии протокола ==');
 // совещание готовит администратор, секретарь — текущий пользователь браузера (volkova, u3)
 const sessOf = async login => {
  const r = await fetch(BASE+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({login,password:'demo'})});
  return (r.headers.get('set-cookie')||'').split(';')[0];
 };
 const chairCookie = await sessOf('morozov');
 const prRes = await rpcAs(admCookie,'meeting.create',{title:'E2E протокол согласования',type:'Техническое',
  date:new Date().toISOString().slice(0,10),time:'09:00',chair:'u2',secretary:'u3',attendees:['u4']});
 const pmid = (prRes.result||{}).id;
 ok('совещание для протокола создано', !!pmid);
 await rpcAs(admCookie,'meeting.conduct',{id:pmid});
 await rpcAs(admCookie,'meeting.decision.add',{id:pmid,text:'E2E решение протокола',resp:'u5',due:new Date(Date.now()+5*864e5).toISOString().slice(0,10)});
 await page.evaluate(()=>pollState());
 await sleep(400);
 await page.evaluate(m=>{App.f.meetTab='prot';openMeeting(m);},pmid);
 await sleep(400);
 const protTxt = ()=>page.evaluate(()=>document.getElementById('drawer-root').textContent);
 ok('вкладка «Протокол»: блок согласования', (await protTxt()).includes('Согласование протокола'));
 ok('исходный статус «Черновик»', (await protTxt()).includes('Черновик'));
 ok('кнопка настройки маршрута', await page.$('#pr-route-btn')!==null);
 await page.evaluate(()=>document.getElementById('pr-route-btn').click());
 await sleep(300);
 ok('окно маршрута открыто', (await page.evaluate(()=>document.getElementById('modal-root').textContent)).includes('Маршрут согласования протокола'));
 await page.evaluate(m=>App.protRouteDefault(m),pmid);
 await sleep(250);
 ok('типовой маршрут: секретарь и председатель', await page.evaluate(()=>App._pr.length===2 && App._pr[0].role==='Секретарь' && App._pr[1].role==='Председатель'));
 await page.evaluate(()=>App.protRouteAdd());
 await sleep(200);
 ok('шаг маршрута добавляется', await page.evaluate(()=>App._pr.length===3));
 await page.evaluate(()=>App.protRouteDel(2));
 await sleep(200);
 ok('шаг маршрута удаляется', await page.evaluate(()=>App._pr.length===2));
 await page.evaluate(()=>document.getElementById('pr-route-save').click());
 await sleep(700);
 ok('маршрут сохранён на сервере', await page.evaluate(m=>{const x=DB.meetings.find(y=>y.id===m);return x.protocol.route.length===2;},pmid));
 ok('таблица маршрута отрисована', await page.evaluate(()=>document.querySelectorAll('#pr-route tbody tr').length===2));
 await page.evaluate(()=>document.getElementById('pr-send').click());
 await sleep(250);
 await page.evaluate(()=>{document.getElementById('pr-note').value='E2E направление';});
 await page.evaluate(()=>document.getElementById('pr-send-go').click());
 await sleep(800);
 ok('статус «Направлен на согласование»', (await protTxt()).includes('Направлен на согласование'));
 ok('дата направления зарегистрирована', await page.evaluate(m=>{const x=DB.meetings.find(y=>y.id===m);return !!x.protocol.sentAt;},pmid));
 ok('кнопки результата согласования доступны', await page.evaluate(()=>!!document.getElementById('pr-agree')&&!!document.getElementById('pr-rework')));
 await page.screenshot({path:'/tmp/e2e/shot_protocol_route.png'});
 await page.evaluate(()=>document.getElementById('pr-rework').click());
 await sleep(250);
 await page.evaluate(()=>document.getElementById('pr-rework-go').click());
 await sleep(300);
 ok('замечания без текста не принимаются', (await page.evaluate(()=>document.getElementById('toasts').textContent)).includes('Замечания должны содержать текст'));
 await page.evaluate(()=>{document.getElementById('pr-cmt').value='E2E замечание к протоколу';});
 await page.evaluate(()=>document.getElementById('pr-rework-go').click());
 await sleep(800);
 ok('статус «На доработке»', (await protTxt()).includes('На доработке'));
 ok('замечание показано в истории отметок', (await protTxt()).includes('E2E замечание к протоколу'));
 await page.evaluate(m=>App.protSend(m),pmid);
 await sleep(250);
 await page.evaluate(()=>document.getElementById('pr-send-go').click());
 await sleep(800);
 await page.evaluate(()=>document.getElementById('pr-agree').click());
 await sleep(250);
 await page.evaluate(()=>document.getElementById('pr-agree-go').click());
 await sleep(800);
 ok('секретарь согласовал в интерфейсе', await page.evaluate(m=>{const x=DB.meetings.find(y=>y.id===m);return x.protocol.route[0].state==='Согласовано';},pmid));
 ok('очередь передана председателю', await page.evaluate(m=>{const r=DB.meetings.find(y=>y.id===m).protocol.route;return r[0].state==='Согласовано'&&r[1].state==='Ожидает';},pmid));
 await rpcAs(chairCookie,'protocol.review',{id:pmid,decision:'Согласовано'});
 await page.evaluate(()=>pollState());
 await sleep(400);
 await page.evaluate(m=>{App.f.meetTab='prot';openMeeting(m);},pmid);
 await sleep(300);
 ok('статус «Согласован» после маршрута', (await protTxt()).includes('Согласован'));
 await rpcAs(chairCookie,'protocol.approve',{id:pmid,note:'E2E утверждение'});
 await page.evaluate(()=>pollState());
 await sleep(500);
 await page.evaluate(m=>{App.f.meetTab='prot';openMeeting(m);},pmid);
 await sleep(400);
 ok('утверждённая редакция 1 отображена', (await protTxt()).includes('Редакция 1'));
 ok('кнопки DOCX и PDF редакции', (await protTxt()).includes('DOCX') && (await protTxt()).includes('PDF'));
 const pv = await page.evaluate(m=>{const x=DB.meetings.find(y=>y.id===m);return x.protocol.versions[0];},pmid);
 ok('редакция содержит снимок решений', pv && pv.decisions.length===1, pv&&pv.decisions.length);
 const prFile = await page.evaluate(async v=>{const r=await fetch('/api/files/'+v.docId+'/'+v.docV+'?fmt=pdf');const b=await r.arrayBuffer();return String.fromCharCode(...new Uint8Array(b).slice(0,4));},pv);
 ok('PDF утверждённой редакции скачивается из карточки', prFile==='%PDF', prFile);
 await page.evaluate((m,v)=>App.protVersion(m,v),pmid,1);
 await sleep(300);
 ok('окно утверждённой редакции со снимком', (await page.evaluate(()=>document.getElementById('modal-root').textContent)).includes('E2E решение протокола'));
 await page.evaluate(()=>App.closeModal(true));
 await rpcAs(admCookie,'protocol.publish',{id:pmid});
 await page.evaluate(()=>pollState());
 await sleep(400);
 await page.evaluate(m=>{App.f.meetTab='prot';openMeeting(m);},pmid);
 await sleep(300);
 ok('статус «Опубликован»', (await protTxt()).includes('Опубликован'));
 const dlg = async d=>{ await d.accept(); };
 page.on('dialog',dlg);
 await page.evaluate(()=>document.getElementById('pr-newver').click());
 await sleep(800);
 page.off('dialog',dlg);
 ok('новая редакция создана из интерфейса', await page.evaluate(m=>{const x=DB.meetings.find(y=>y.id===m);return x.protocol.status==='Черновик'&&x.protocol.versions.length===1;},pmid));
 ok('история редакций сохранена', (await protTxt()).includes('История редакций (1)'));
 await page.evaluate(()=>{App.closeDrawer();nav('meetings');App.f.mt.tab='prot';renderView();});
 await sleep(350);
 ok('режим «Протоколы» в реестре совещаний', (await page.evaluate(()=>document.getElementById('view').textContent)).includes('E2E протокол согласования'));
 await page.screenshot({path:'/tmp/e2e/shot_protocol_versions.png'});

 console.log('== M16 §2.10: поручения из решений совещаний ==');
 const drRes = await rpcAs(admCookie,'meeting.create',{title:'E2E поручения из решений',type:'Оперативное',
  date:new Date().toISOString().slice(0,10),time:'08:00',chair:'u2',secretary:'u3',attendees:['u5','u6']});
 const dmid=(drRes.result||{}).id;
 await rpcAs(admCookie,'meeting.agenda.add',{id:dmid,title:'Вопрос E2E по поручениям',reporter:'u3'});
 const decRes = await rpcAs(admCookie,'meeting.decision.add',{id:dmid,text:'E2E решение для поручения',resp:'u5',
  due:new Date(Date.now()+6*864e5).toISOString().slice(0,10),agendaN:1});
 const ddid=((decRes.result||{}).decisions||[{}])[0].id;
 ok('решение зарегистрировано вторым пользователем', !!ddid);
 await page.evaluate(()=>pollState());
 await sleep(400);
 await page.evaluate(m=>{App.f.meetTab='dec';openMeeting(m);},dmid);
 await sleep(300);
 ok('кнопка «В поручение» в решении', (await page.evaluate(()=>document.getElementById('drawer-root').textContent)).includes('В поручение'));
 await page.evaluate((m,d)=>App.directiveModal(m,d),dmid,ddid);
 await sleep(300);
 const drTxt = await page.evaluate(()=>document.getElementById('modal-root').textContent);
 ok('форма поручения: поля ТЗ §2.10', ['Наименование','Описание','Проект','Исполнитель','Соисполнители','Дата постановки','Срок исполнения','Приоритет','Критерии завершения','Источник поручения'].every(x=>drTxt.includes(x)));
 ok('исполнитель и проект предзаполнены', await page.evaluate(()=>val('dr-as')==='u5'&&!!val('dr-proj')));
 ok('источник подставлен из решения', await page.evaluate(()=>val('dr-src').includes('Решение №1')));
 await page.evaluate(()=>{
  document.getElementById('dr-title').value='E2E поручение браузера';
  document.getElementById('dr-crit').value='Отчёт подписан испытательной группой';
  document.querySelector('.dr-co[value="u6"]').checked=true;
 });
 await page.evaluate(()=>document.getElementById('dr-save').click());
 await sleep(900);
 const dt = await page.evaluate(m=>{
  const d=DB.meetings.find(x=>x.id===m).decisions[0];
  const t=DB.tasks.find(x=>x.id===(d.taskIds||[])[0]);
  return t?{id:t.id,code:t.code,type:t.type,dr:t.directive}:null;
 },dmid);
 ok('поручение создано как задача M02', !!dt && dt.type==='directive', dt&&dt.code);
 ok('соисполнитель сохранён', dt&&dt.dr.coassignees.join(',')==='u6', dt&&dt.dr.coassignees);
 ok('критерии завершения сохранены', dt&&dt.dr.criteria==='Отчёт подписан испытательной группой');
 ok('ссылки на совещание, решение и пункт повестки', dt&&dt.dr.meetingId===dmid&&dt.dr.decisionN===1&&dt.dr.agendaN===1);
 await page.screenshot({path:'/tmp/e2e/shot_directive_form.png'});
 await page.evaluate(t=>openTask(t),dt.id);
 await sleep(400);
 ok('карточка задачи: блок «Основание поручения»', await page.$('#dir-basis')!==null);
 const basisTxt = await page.evaluate(()=>(document.getElementById('dir-basis')||{}).textContent||'');
 ok('основание содержит критерии и источник', basisTxt.includes('Отчёт подписан')&&basisTxt.includes('Решение №1'));
 await page.evaluate(()=>{const el=[...document.querySelectorAll('#dir-basis .link')].find(x=>x.textContent.includes('СОВ-'));if(el)el.click();});
 await sleep(500);
 ok('обратный переход из задачи к совещанию', (await page.evaluate(()=>document.getElementById('drawer-root').textContent)).includes('E2E поручения из решений'));
 await page.evaluate((m,d)=>{App.f.meetTab='dec';openMeeting(m);App.directiveModal(m,d);},dmid,ddid);
 await sleep(350);
 ok('предупреждение о повторном создании', (await page.evaluate(()=>document.getElementById('modal-root').textContent)).includes('уже создано поручение'));
 const dlg2 = async d=>{ await d.accept(); };
 page.on('dialog',dlg2);
 await page.evaluate(()=>document.getElementById('dr-save').click());
 await sleep(1100);
 page.off('dialog',dlg2);
 ok('второе поручение создано после подтверждения', await page.evaluate(m=>DB.meetings.find(x=>x.id===m).decisions[0].taskIds.length===2,dmid));
 await page.evaluate((m,d)=>App.decisionEdit(m,d),dmid,ddid);
 await sleep(300);
 await page.evaluate(()=>{document.getElementById('de-text').value='E2E решение изменено без нового поручения';});
 await page.evaluate((m,d)=>App.decisionEditSave(m,d),dmid,ddid);
 await sleep(800);
 ok('правка решения не создаёт поручение повторно', await page.evaluate(m=>{
  const d=DB.meetings.find(x=>x.id===m).decisions[0];
  return d.taskIds.length===2 && d.text.includes('изменено');
 },dmid));
 await page.evaluate(m=>{App.f.meetTab='dir';openMeeting(m);},dmid);
 await sleep(350);
 ok('вкладка «Поручения» показывает соисполнителей', (await page.evaluate(()=>document.getElementById('drawer-root').textContent)).includes('соисполнители'));
 await page.screenshot({path:'/tmp/e2e/shot_directive_list.png'});
 await page.evaluate(()=>App.closeDrawer());

 console.log('== M16 §2.11: реестр поручений и приёмка результата ==');
 await page.evaluate(()=>{nav('meetings');App.f.mt.tab='dir';App.f.mt.df={};renderView();});
 await sleep(450);
 ok('реестр поручений открыт', await page.$('#dir-registry')!==null);
 const regHead = await page.evaluate(()=>(document.querySelector('#dir-registry thead')||{}).textContent||'');
 ok('колонки реестра по ТЗ §2.11', ['Совещание','Протокол','Решение','Исполнитель','Соисполнители','Срок','Статус','Дата факта','Результат','Документы'].every(x=>regHead.includes(x)));
 ok('созданное поручение видно в реестре', (await page.evaluate(()=>document.getElementById('dir-registry').textContent)).includes('E2E поручение браузера'));
 await page.screenshot({path:'/tmp/e2e/shot_directive_registry.png'});
 await page.evaluate(()=>{const el=document.getElementById('drf-s');el.value='Не начато';el.dispatchEvent(new Event('change'));});
 await sleep(400);
 ok('фильтр реестра по статусу применён', await page.evaluate(()=>App.f.mt.df.s==='Не начато'));
 await page.evaluate(()=>{const el=document.getElementById('drf-s');el.value='';el.dispatchEvent(new Event('change'));});
 await sleep(350);
 const rtid = await page.evaluate(()=>DB.tasks.find(t=>t.title==='E2E поручение браузера').id);
 await page.evaluate(t=>{App.f.taskTab='dir';openTask(t);},rtid);
 await sleep(450);
 ok('вкладка «Поручение» в карточке задачи', await page.$('#dir-card')!==null);
 const dirTxt = await page.evaluate(()=>document.getElementById('drawer-root').textContent);
 ok('контроль исполнения и приёмка в карточке', dirTxt.includes('Контроль исполнения поручения')&&dirTxt.includes('Приёмка результата руководителем'));
 await page.evaluate(()=>document.getElementById('dir-extend-btn').click());
 await sleep(350);
 await page.evaluate(()=>{
  document.getElementById('dir-due').value=new Date(Date.now()+20*864e5).toISOString().slice(0,10);
  document.getElementById('dir-reason').value='E2E продление по решению председателя';
 });
 await page.evaluate(()=>document.getElementById('dir-extend-go').click());
 await sleep(1000);
 const afterExt = await page.evaluate(()=>document.getElementById('drawer-root').textContent);
 ok('продление зафиксировано в истории', afterExt.includes('История продления срока (1)'));
 ok('основание продления показано', afterExt.includes('E2E продление по решению председателя'));
 await page.evaluate(()=>document.getElementById('dir-attach-btn').click());
 await sleep(350);
 await page.evaluate(()=>document.getElementById('dir-attach-go').click());
 await sleep(900);
 ok('подтверждающий документ приложен', (await page.evaluate(()=>document.getElementById('drawer-root').textContent)).includes('Документы, подтверждающие выполнение (1)'));
 await page.evaluate(()=>{document.getElementById('dir-result').value='E2E результат поручения';document.getElementById('dir-prog').value='60';});
 await page.evaluate(()=>document.getElementById('dir-save').click());
 await sleep(900);
 ok('результат поручения сохранён', await page.evaluate(t=>DB.tasks.find(x=>x.id===t).result==='E2E результат поручения',rtid));
 await page.screenshot({path:'/tmp/e2e/shot_directive_card.png'});
 // приёмка результата — руководитель подразделения
 await page.evaluate(()=>{App.closeDrawer();App.closeModal(true);App.logout();});
 await page.waitForSelector('.login-box',{timeout:10000});
 await page.evaluate(()=>{App.pickUser('morozov');});
 await page.click('.login-row .btn.pri');
 await page.waitForSelector('.shell',{timeout:10000});
 await sleep(500);
 await page.evaluate(async t=>{await rpc('task.status',{id:t,to:'В работе'});await rpc('task.status',{id:t,to:'На проверке',result:'E2E результат поручения'});},rtid);
 await sleep(700);
 await page.evaluate(t=>{App.f.taskTab='dir';openTask(t);},rtid);
 await sleep(400);
 ok('кнопка приёмки доступна руководителю', await page.$('#dir-accept-btn')!==null);
 await page.evaluate(()=>document.getElementById('dir-accept-btn').click());
 await sleep(350);
 await page.evaluate(()=>{document.getElementById('dir-acc-cmt').value='E2E решение исполнено и принято';});
 await page.evaluate(()=>document.getElementById('dir-accept-go').click());
 await sleep(1000);
 const accTxt = await page.evaluate(()=>document.getElementById('drawer-root').textContent);
 ok('приёмка зафиксирована в карточке', accTxt.includes('Принято')&&accTxt.includes('E2E решение исполнено и принято'));
 ok('статус поручения «Выполнено»', await page.evaluate(t=>dirStatus(DB.tasks.find(x=>x.id===t))==='Выполнено',rtid));
 ok('дата фактического исполнения проставлена', await page.evaluate(t=>!!(DB.tasks.find(x=>x.id===t).directive||{}).factDate,rtid));
 await page.evaluate(()=>{App.closeDrawer();nav('meetings');App.f.mt.tab='over';renderView();});
 await sleep(450);
 ok('режим «Просроченные поручения»', (await page.evaluate(()=>document.getElementById('view').textContent)).includes('Просроченные поручения'));
 await page.evaluate(()=>{App.f.mt.tab='dir';App.f.mt.df={};renderView();});
 await sleep(350);

 console.log('== Фильтры-списки: обработчик изменения ==');
 await page.evaluate(()=>{nav('tasks');App.f.tk.proj='';renderView();});
 await sleep(300);
 const filterWorks = await page.evaluate(()=>{
  const el=document.getElementById('tk-proj'); if(!el)return 'нет списка';
  el.value=DB.projects[0].id;
  el.dispatchEvent(new Event('change'));
  return App.f.tk.proj===DB.projects[0].id;
 });
 ok('выбор в списке фильтра применяется', filterWorks===true, filterWorks);
 await page.evaluate(()=>{App.f.tk.proj='';renderView();});
 await sleep(200);

 console.log('== Права: наблюдатель ==');
 await page.evaluate(()=>App.logout());
 await page.waitForSelector('.login-box',{timeout:10000});
 await page.evaluate(()=>{ App.pickUser('zaytseva'); });
 await page.click('.login-row .btn.pri');
 await page.waitForSelector('.shell',{timeout:10000});
 await sleep(300);
 ok('наблюдатель: нет M14 в навигации', !(await page.evaluate(()=>[...document.querySelectorAll('.nav a')].some(a=>a.textContent.includes('Администрирование')))));
 const denied = await page.evaluate(async()=>{ const r=await rpc('project.create',{name:'x',cat:'НИОКР',pm:'u3',start:'2026-12-01',end:'2026-12-10',budgetHours:10}); return r===false; });
 ok('наблюдатель: создание отклонено', denied===true);
 await sleep(200);
 ok('тост 403 показан', (await page.evaluate(()=>document.getElementById('toasts').textContent)).includes('403'));

 console.log('== M14: планировщик уведомлений ==');
 await page.evaluate(()=>App.logout());
 await page.waitForSelector('.login-box',{timeout:10000});
 await page.evaluate(()=>{ App.pickUser('admin'); });
 await page.click('.login-row .btn.pri');
 await page.waitForSelector('.shell',{timeout:10000});
 await page.evaluate(()=>{ nav('admin'); App.f.adm='sys'; renderView(); });
 await sleep(400);
 ok('карточка планировщика в M14', (await page.evaluate(()=>document.getElementById('view').textContent)).includes('Планировщик уведомлений и напоминаний'));
 await page.evaluate(()=>App.notifTick());
 await sleep(800);
 ok('внеочередной цикл планировщика отработал', (await page.evaluate(()=>document.getElementById('toasts').textContent)).includes('Планировщик отработал'));
 await page.screenshot({path:'/tmp/e2e/shot_notif_admin.png'});

 console.log('== M14: файловые журналы ==');
 ok('карточка файловых журналов', (await page.evaluate(()=>document.getElementById('view').textContent)).includes('Файловые журналы'));
 await page.evaluate(()=>App.logs('supip.log'));
 await sleep(700);
 const logTxt = await page.evaluate(()=>document.getElementById('modal-root').textContent);
 ok('журнал работы открыт в окне', logTxt.includes('Файловые журналы') && logTxt.includes('supip.log'));
 ok('строки журнала отображаются', /\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}/.test(logTxt));
 ok('есть ссылка скачивания журнала', await page.$('a[href="/api/logs/supip.log"]')!==null);
 await page.screenshot({path:'/tmp/e2e/shot_logs.png'});
 await page.evaluate(()=>App.logs('setup.log'));
 await sleep(600);
 ok('переключение на журнал настройки', (await page.evaluate(()=>document.getElementById('modal-root').textContent)).includes('setup.log'));
 await page.evaluate(()=>App.closeModal(true));
 await page.evaluate(()=>App.clientLog());
 await sleep(400);
 ok('журнал клиента (буфер браузера)', (await page.evaluate(()=>document.getElementById('modal-root').textContent)).includes('Журнал клиента'));
 await page.evaluate(()=>App.closeModal(true));

 console.log('== Сессия и выход ==');
 await page.evaluate(()=>App.logout());
 await sleep(300);
 ok('после выхода экран входа', await page.$('.login-box')!==null);

 console.log('== Ошибки страницы ==');
 ok('нет pageerror/console.error', errors.length===0, errors.slice(0,4).join(' | '));

 await browser.close();
 await rpcAs(admCookie,'admin.reset');   // возврат к эталонному набору
 console.log('\nИТОГ E2E: '+PASS+' ok, '+FAIL+' FAIL');
 process.exit(FAIL?1:0);
})().catch(e=>{console.error('E2E CRASH:',e);process.exit(2);});
